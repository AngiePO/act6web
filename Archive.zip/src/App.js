import Poke from './Poke';
import BasicExample from './etiquetas'


function App() {
  return (
    
    <div className="App">
      <BasicExample/>
      <Poke/>
    </div>

  );
}

export default App;