import React, {useEffect, useState} from "react"; 

function Poke() {

    const [Poke, setPoke] = useState(null);

    useEffect( () => {
        fetch("https://pokeapi.co/api/v2/pokemon/jigglypuff")
        .then((res) => res.json())
        .then((data) => {
            console.log(data);
            setPoke(data);
        });
    }, []);

    return (
    <div> 
        Poke 
        {Poke && (
        <div>
            {" "}
            <img src={Poke.sprites.front_default} alt="" width="500" heigth="500"/> {Poke.title}
            <img src={Poke.sprites.front_shiny} alt="" width="500" heigth="500" /> {Poke.title}
            <img src={Poke.sprites.back_default} alt="" width="500" heigth="500" /> {Poke.title}
            <img src={Poke.sprites.back_shiny} alt="" width="500" heigth="500" /> {Poke.title}
      </div>
    )}
    </div>
    );
}

export default Poke;