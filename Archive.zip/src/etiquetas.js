import Badge from 'react-bootstrap/Badge';

function BasicExample() {
  return (
    <div>
      <h1 >
        Este es una api de pokemon <Badge bg="secondary" >.</Badge>
      </h1>
      <h2>
        el pokemos que elejí se llama jigglypuff <Badge bg="secondary">.</Badge>
      </h2>
      <h3>
        a continuación presento fotos de este, con su espalda y frente y de distintos tonos  <Badge bg="secondary">.</Badge>
      </h3>
    </div>
  );
}

export default BasicExample;